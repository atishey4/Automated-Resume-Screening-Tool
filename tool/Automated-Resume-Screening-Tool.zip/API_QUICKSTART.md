"""Quick startup and API documentation."""

# Automated Resume Screening Tool - Quick Start

## Setup

1. **Initialize database:**
   ```bash
   python db/init_db.py
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Running the API

Start the FastAPI server:
```bash
uvicorn api.app:app --reload --host 0.0.0.0 --port 8000
```

Access the API:
- Interactive API docs: http://localhost:8000/docs
- Alternative docs: http://localhost:8000/redoc

## API Endpoints

### 1. Create a Job
**POST** `/job/create`

Request:
```json
{
  "title": "Senior Python Engineer",
  "description": "We need an expert in Python, SQL, and AWS with 5+ years of experience",
  "requirements": "Python, SQL, AWS, Docker",
  "skills": "python,sql,aws,docker",
  "experience_years": 5
}
```

Response:
```json
{
  "job_id": 1,
  "title": "Senior Python Engineer",
  "message": "Job created successfully with ID 1"
}
```

### 2. Upload and Parse Resume
**POST** `/resume/upload`

Parameters:
- `file`: Resume file (PDF, DOCX, or TXT)
- `candidate_name`: Candidate's name
- `candidate_email`: Candidate's email (optional)

Response:
```json
{
  "candidate_id": 1,
  "resume_id": 1,
  "parsed_data": {
    "skills": ["python", "sql", "aws"],
    "total_years": 4.0,
    "skill_count": 3
  },
  "message": "Resume uploaded and parsed successfully (ID: 1)"
}
```

### 3. Rank Resumes Against a Job
**POST** `/rank/{job_id}`

Response:
```json
{
  "job_id": 1,
  "total_resumes": 3,
  "results": [
    {
      "resume_id": 2,
      "candidate_name": "John Doe",
      "match_score": 0.82,
      "skills_match": {
        "matched": ["python", "sql", "aws"],
        "missing": ["docker"],
        "coverage": "3/4"
      },
      "experience_match": {
        "resume_years": 5.0,
        "jd_years": 5.0,
        "gap": 0.0
      }
    }
  ]
}
```

## Data Flow

1. **Upload Resume** → Extract text (PDF/DOCX/TXT) → Parse skills & years
2. **Store Resume** → Save raw text and parsed JSON to database
3. **Create Job** → Store job requirements and description
4. **Rank** → Compute similarity + skill coverage + years experience - penalty
5. **Results** → Sorted by match_score, with detailed breakdown

## Scoring Formula

```
score = 0.55×similarity + 0.35×(coverage) + 0.10×(years) - gap_penalty
```

Where:
- **similarity**: Cosine similarity between JD and resume skills (via sentence-transformers)
- **coverage**: Must-have skills matched / total must-have skills
- **years**: min(1, candidate_years / required_years)
- **gap_penalty**: Skill gaps + experience gaps combined

## Database Schema

- **jobs**: Job postings
- **candidates**: Candidate information
- **resumes**: Resume documents and metadata
- **features**: Extracted resume features
- **rankings**: Match scores and results
