"""
Quick Guide for Running the Resume Screening Dashboard

## Prerequisites

1. Initialize the database:
   ```bash
   python db/init_db.py
   ```

2. Install dependencies (if not already done):
   ```bash
   pip install -r requirements.txt
   ```

## Running the Dashboard

Start the Streamlit app:
```bash
streamlit run src/dashboard.py
```

The dashboard will open in your default browser at:
http://localhost:8501

## Using the Dashboard

### Step 1: Upload Resumes
- Click "📤 Upload Resumes" in the left sidebar
- Select one or more resume files (PDF, DOCX, or TXT)
- Click "Upload & Parse Resumes"
- Wait for processing to complete

### Step 2: Enter Job Description
- In the main area, paste or type the job description
- Include responsibilities, requirements, and desired skills

### Step 3: Specify Must-Have Skills
- Enter skills as a comma-separated list
- Example: "sql, excel, power bi, python"
- The dashboard will display the count of required skills

### Step 4: Set Experience Requirement
- Use the number input to set minimum years of experience
- Default is 3 years

### Step 5: Screen Resumes
- Click the "🔍 Screen Resumes" button
- The app will rank all uploaded resumes

### Step 6: View Results
Results are displayed in a ranked table showing:
- Candidate name and email
- Match score (0.0 - 1.0)
- Matched skills (must-have skills found in resume)
- Missing skills (must-have skills NOT in resume)
- Skill coverage (e.g., 2/3)
- Years of experience
- Total unique skills detected

### Step 7: Export Results
- Click "📥 Download Results as CSV"
- Save the screening results for further analysis

## Scoring Explanation

The match score uses this formula:
```
score = 0.55×similarity + 0.35×coverage + 0.10×experience - penalty
```

Where:
- **Similarity (55%)**: How relevant the resume is to the job description
- **Coverage (35%)**: Percentage of must-have skills the candidate has
- **Experience (10%)**: Candidate's years relative to requirement
- **Penalty**: Deduction for missing skills and experience gaps

## Example Workflow

1. Upload: resume_alice.txt, resume_bob.txt, resume_carol.txt
2. Job Description: "Need a data analyst with SQL, Excel, and Power BI expertise"
3. Must-Have Skills: "sql, excel, power bi"
4. Min Years: 3
5. Click Screen
6. View ranked results and download as CSV

## Troubleshooting

**Database Error:**
- Ensure db/init_db.py has been run
- Check that db/resumes.db exists in the db/ folder

**File Upload Issues:**
- Only PDF, DOCX, and TXT files are supported
- Ensure file names don't contain special characters

**No Results:**
- Make sure at least one resume has been uploaded
- Check that job description and skills are filled in

"""
