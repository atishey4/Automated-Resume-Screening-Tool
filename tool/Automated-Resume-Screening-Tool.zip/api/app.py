"""FastAPI application for Resume Screening Tool."""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel

# Add src to path for imports
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from ingest import TextExtractor, ResumeStore
from extract import parse_resume
from rank import rank_job

app = FastAPI(
    title="Automated Resume Screening Tool",
    description="AI-powered resume screening and matching",
    version="1.0.0",
)

DB_PATH = str(project_root / "db" / "resumes.db")


# ============================================================================
# Request/Response Models
# ============================================================================


class JobCreateRequest(BaseModel):
    """Request model for job creation."""
    title: str
    description: str
    requirements: Optional[str] = None
    skills: Optional[str] = None
    experience_years: Optional[int] = None


class JobCreateResponse(BaseModel):
    """Response model for job creation."""
    job_id: int
    title: str
    message: str


class ResumeUploadResponse(BaseModel):
    """Response model for resume upload."""
    candidate_id: int
    resume_id: int
    parsed_data: Dict[str, Any]
    message: str


class RankingResult(BaseModel):
    """Single ranking result."""
    resume_id: int
    candidate_name: str
    match_score: float
    skills_match: Dict[str, Any]
    experience_match: Dict[str, Any]


class RankingResponse(BaseModel):
    """Response model for ranking."""
    job_id: int
    total_resumes: int
    results: List[RankingResult]


class ErrorResponse(BaseModel):
    """Error response model."""
    error: str
    details: Optional[str] = None


# ============================================================================
# Utility Functions
# ============================================================================


def get_db_connection() -> sqlite3.Connection:
    """Get database connection."""
    if not Path(DB_PATH).exists():
        raise HTTPException(status_code=500, detail="Database not initialized")
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ============================================================================
# Endpoints
# ============================================================================


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "message": "Automated Resume Screening Tool API",
        "version": "1.0.0",
        "endpoints": [
            "POST /job/create - Create a new job",
            "POST /resume/upload - Upload and parse a resume",
            "POST /rank/{job_id} - Rank resumes against a job",
        ],
    }


@app.post("/job/create", response_model=JobCreateResponse)
async def create_job(request: JobCreateRequest) -> JobCreateResponse:
    """
    Create a new job in the database.
    
    Args:
        request: Job details (title, description, requirements, skills, experience_years)
        
    Returns:
        JobCreateResponse with job_id and confirmation
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO jobs (title, description, requirements, skills, experience_years)
            VALUES (?, ?, ?, ?, ?)
        """, (
            request.title,
            request.description,
            request.requirements,
            request.skills,
            request.experience_years,
        ))
        
        job_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return JobCreateResponse(
            job_id=job_id,
            title=request.title,
            message=f"Job created successfully with ID {job_id}",
        )
        
    except sqlite3.Error as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating job: {e}")


@app.post("/resume/upload", response_model=ResumeUploadResponse)
async def upload_resume(
    file: UploadFile = File(...),
    candidate_name: str = "Unknown",
    candidate_email: Optional[str] = None,
) -> ResumeUploadResponse:
    """
    Upload a resume file, extract text, parse features, and store in database.
    
    Args:
        file: Resume file (PDF, DOCX, or TXT)
        candidate_name: Name of candidate
        candidate_email: Email of candidate
        
    Returns:
        ResumeUploadResponse with parsed data and IDs
    """
    try:
        # Validate file type
        allowed_types = {".pdf", ".docx", ".txt"}
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in allowed_types:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file_ext}. Allowed: {allowed_types}",
            )
        
        # Save uploaded file temporarily
        temp_path = project_root / "resumes" / file.filename
        temp_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(temp_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        # Extract text from file
        extracted_text = TextExtractor.read_text(str(temp_path))
        
        # Parse resume features
        parsed_data = parse_resume(extracted_text)
        
        # Create or get candidate
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT id FROM candidates WHERE email = ?",
            (candidate_email,)
        )
        candidate = cursor.fetchone()
        
        if candidate:
            candidate_id = candidate["id"]
        else:
            cursor.execute(
                "INSERT INTO candidates (name, email) VALUES (?, ?)",
                (candidate_name, candidate_email),
            )
            candidate_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        
        # Save resume to database
        store = ResumeStore(db_path=DB_PATH)
        success, resume_id, message = store.save_resume(
            candidate_id=candidate_id,
            file_path=str(temp_path),
            raw_text=extracted_text,
            parsed_data=parsed_data,
        )
        
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return ResumeUploadResponse(
            candidate_id=candidate_id,
            resume_id=resume_id,
            parsed_data=parsed_data,
            message=f"Resume uploaded and parsed successfully (ID: {resume_id})",
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading resume: {e}")


@app.post("/rank/{job_id}", response_model=RankingResponse)
async def rank_resumes(job_id: int) -> RankingResponse:
    """
    Rank all uploaded resumes against a specific job.
    
    Args:
        job_id: ID of the job to rank against
        
    Returns:
        RankingResponse with sorted ranking results
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get job details
        cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        job_row = cursor.fetchone()
        if not job_row:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        job_description = job_row["description"] or ""
        min_years = job_row["experience_years"] or 0
        
        # Get all resumes
        cursor.execute("""
            SELECT r.id, r.candidate_id, r.parsed_json, c.name
            FROM resumes r
            JOIN candidates c ON r.candidate_id = c.id
        """)
        resume_rows = cursor.fetchall()
        
        if not resume_rows:
            return RankingResponse(
                job_id=job_id,
                total_resumes=0,
                results=[],
            )
        
        # Rank each resume
        ranking_results = []
        for resume_row in resume_rows:
            resume_id = resume_row["id"]
            candidate_id = resume_row["candidate_id"]
            candidate_name = resume_row["name"]
            
            try:
                parsed_data = json.loads(resume_row["parsed_json"] or "{}")
            except json.JSONDecodeError:
                parsed_data = {}
            
            success, ranking_id, match_score, reasons = rank_job(
                jd_text=job_description,
                resume_features=parsed_data,
                job_id=job_id,
                candidate_id=candidate_id,
                resume_id=resume_id,
                min_years_required=min_years,
                db_path=DB_PATH,
            )
            
            if success:
                # Get the stored skills_match and experience_match from database
                cursor.execute(
                    "SELECT skills_match, experience_match FROM rankings WHERE id = ?",
                    (ranking_id,)
                )
                rank_data = cursor.fetchone()
                
                skills_match = json.loads(rank_data["skills_match"]) if rank_data else {}
                experience_match = json.loads(rank_data["experience_match"]) if rank_data else {}
                
                ranking_results.append(
                    RankingResult(
                        resume_id=resume_id,
                        candidate_name=candidate_name,
                        match_score=match_score,
                        skills_match=skills_match,
                        experience_match=experience_match,
                    )
                )
        
        conn.close()
        
        # Sort by match_score descending
        ranking_results.sort(key=lambda x: x.match_score, reverse=True)
        
        return RankingResponse(
            job_id=job_id,
            total_resumes=len(resume_rows),
            results=ranking_results,
        )
        
    except HTTPException:
        raise
    except sqlite3.Error as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error ranking resumes: {e}")


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    try:
        conn = get_db_connection()
        conn.close()
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
