"""
Database initialization script for Resume Screening Tool
Creates SQLite database and tables from schema.sql
"""

import sqlite3
import os
from pathlib import Path


class DatabaseInitializer:
    """Handles database initialization and connection management"""
    
    def __init__(self, db_path: str = None):
        """
        Initialize the database initializer
        
        Args:
            db_path (str): Path to the SQLite database file.
                          Defaults to db/resumes.db
        """
        if db_path is None:
            db_dir = Path(__file__).parent
            db_path = os.path.join(db_dir, "resumes.db")
        
        self.db_path = db_path
        self.schema_path = os.path.join(Path(__file__).parent, "schema.sql")
    
    def create_database(self):
        """Create database file if it doesn't exist"""
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
            print(f"Created directory: {db_dir}")
    
    def read_schema(self) -> str:
        """
        Read SQL schema from schema.sql file
        
        Returns:
            str: SQL schema content
            
        Raises:
            FileNotFoundError: If schema.sql file is not found
        """
        if not os.path.exists(self.schema_path):
            raise FileNotFoundError(f"Schema file not found: {self.schema_path}")
        
        with open(self.schema_path, "r") as f:
            return f.read()
    
    def execute_schema(self, connection: sqlite3.Connection):
        """
        Execute SQL schema to create tables
        
        Args:
            connection: SQLite database connection
        """
        schema = self.read_schema()
        cursor = connection.cursor()
        
        # Split schema into individual statements and execute
        statements = schema.split(";")
        for statement in statements:
            statement = statement.strip()
            if statement:
                try:
                    cursor.execute(statement)
                except sqlite3.Error as e:
                    print(f"Error executing statement: {statement[:50]}...")
                    print(f"Error: {e}")
                    raise
        
        connection.commit()
    
    def initialize(self) -> bool:
        """
        Initialize the database with schema
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            print(f"Initializing database at: {self.db_path}")
            
            # Create database directory
            self.create_database()
            
            # Connect to database (creates it if not exists)
            connection = sqlite3.connect(self.db_path)
            print("✓ Database connection established")
            
            # Execute schema
            self.execute_schema(connection)
            print("✓ Schema tables created successfully")
            
            # Verify tables were created
            cursor = connection.cursor()
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
            )
            tables = cursor.fetchall()
            print(f"✓ Created {len(tables)} tables:")
            for table in tables:
                print(f"  - {table[0]}")
            
            connection.close()
            print("✓ Database initialization completed successfully\n")
            return True
            
        except Exception as e:
            print(f"✗ Error during database initialization: {e}")
            return False
    
    def reset_database(self) -> bool:
        """
        Reset the database by deleting and recreating it
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if os.path.exists(self.db_path):
                os.remove(self.db_path)
                print(f"Deleted existing database: {self.db_path}")
            
            return self.initialize()
        except Exception as e:
            print(f"Error resetting database: {e}")
            return False


def main():
    """Main entry point for database initialization"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Initialize Resume Screening Database")
    parser.add_argument(
        "--db",
        type=str,
        default=None,
        help="Path to database file (default: db/resumes.db)"
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset database (delete and recreate)"
    )
    
    args = parser.parse_args()
    
    initializer = DatabaseInitializer(db_path=args.db)
    
    if args.reset:
        success = initializer.reset_database()
    else:
        success = initializer.initialize()
    
    return 0 if success else 1


if __name__ == "__main__":
    exit(main())
