"""
Automated Resume Screening Tool
Main entry point for the application
"""

import sys
from pathlib import Path


def main():
    """Main function to run the resume screening tool"""
    print("Welcome to Automated Resume Screening Tool")
    print("=" * 50)
    
    # Add src to path for imports
    src_path = Path(__file__).parent / "src"
    sys.path.insert(0, str(src_path))
    
    # TODO: Add main application logic here


if __name__ == "__main__":
    main()
