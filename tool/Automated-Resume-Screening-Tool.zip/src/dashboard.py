"""Streamlit dashboard for resume screening."""

import json
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import streamlit as st
import pandas as pd

# Add src to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from ingest import TextExtractor, ResumeStore
from extract import parse_resume
from rank import rank_job

DB_PATH = str(project_root / "db" / "resumes.db")

st.set_page_config(
    page_title="Resume Screening Tool",
    page_icon="📋",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("📋 Automated Resume Screening Tool")
st.markdown("---")

# Initialize session state
if "uploaded_resumes" not in st.session_state:
    st.session_state.uploaded_resumes = []
if "ranking_results" not in st.session_state:
    st.session_state.ranking_results = None
if "job_desc" not in st.session_state:
    st.session_state.job_desc = ""
if "skills" not in st.session_state:
    st.session_state.skills = "sql, excel, power bi"
if "min_years" not in st.session_state:
    st.session_state.min_years = 3.0


def load_jd_from_file(uploaded_file) -> None:
    """Load a job description file and populate the screening form."""
    try:
        file_ext = Path(uploaded_file.name).suffix.lower()
        uploaded_bytes = uploaded_file.getvalue()

        if file_ext == ".json":
            jd_data = json.loads(uploaded_bytes.decode("utf-8"))
            st.session_state.job_desc = jd_data.get("description", "")
            must_have = jd_data.get("must_have") or jd_data.get("must_have_skills") or []
            st.session_state.skills = ", ".join(must_have) if must_have else st.session_state.skills
            st.session_state.min_years = float(jd_data.get("minimum_years_required", st.session_state.min_years) or st.session_state.min_years)
        else:
            st.session_state.job_desc = uploaded_bytes.decode("utf-8", errors="ignore")

        st.session_state.ranking_results = None
        st.success(f"✅ Loaded JD from {uploaded_file.name}")
    except Exception as e:
        st.error(f"Could not load JD file: {e}")


def load_jd_from_uploaded_files(uploaded_files) -> None:
    """Load the selected JD from a list of uploaded files."""
    if not uploaded_files:
        st.warning("Please upload at least one JD file first.")
        return

    selected_name = st.selectbox(
        "Choose a JD to load",
        options=[file.name for file in uploaded_files],
        key="selected_jd_file",
    )

    selected_file = next((file for file in uploaded_files if file.name == selected_name), None)
    if selected_file is not None:
        load_jd_from_file(selected_file)


def get_db_connection() -> Optional[sqlite3.Connection]:
    """Get database connection."""
    try:
        if not Path(DB_PATH).exists():
            st.error("❌ Database not found. Please run `python db/init_db.py` first.")
            return None
        
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        st.error(f"Database connection error: {e}")
        return None


def upload_and_parse_resume(uploaded_file, candidate_name: str, candidate_email: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Upload, parse, and store a resume."""
    try:
        # Validate file type
        allowed_types = {".pdf", ".docx", ".txt"}
        file_ext = Path(uploaded_file.name).suffix.lower()
        if file_ext not in allowed_types:
            st.warning(f"⚠️ Unsupported file type: {file_ext}. Skipping {uploaded_file.name}")
            return None
        
        # Save uploaded file temporarily
        temp_path = project_root / "resumes" / uploaded_file.name
        temp_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.read())
        
        # Extract text from file
        extracted_text = TextExtractor.read_text(str(temp_path))
        
        # Parse resume features
        parsed_data = parse_resume(extracted_text)
        
        # Create or get candidate
        conn = get_db_connection()
        if not conn:
            return None
        
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT id FROM candidates WHERE email = ?",
            (candidate_email,)
        )
        candidate = cursor.fetchone()
        
        if candidate:
            candidate_id = candidate["id"]
        else:
            cursor.execute(
                "INSERT INTO candidates (name, email) VALUES (?, ?)",
                (candidate_name, candidate_email),
            )
            candidate_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        
        # Save resume to database
        store = ResumeStore(db_path=DB_PATH)
        success, resume_id, message = store.save_resume(
            candidate_id=candidate_id,
            file_path=str(temp_path),
            raw_text=extracted_text,
            parsed_data=parsed_data,
        )
        
        if success:
            return {
                "candidate_id": candidate_id,
                "resume_id": resume_id,
                "candidate_name": candidate_name,
                "parsed_data": parsed_data,
            }
        else:
            st.error(f"Failed to save resume: {message}")
            return None
            
    except Exception as e:
        st.error(f"Error uploading resume: {e}")
        return None


def screen_resumes(
    job_description: str,
    must_have_skills: List[str],
    min_years_required: float = 0.0,
) -> Optional[pd.DataFrame]:
    """Screen all uploaded resumes against job description."""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        
        cursor = conn.cursor()
        
        # Get all resumes
        cursor.execute("""
            SELECT r.id, r.candidate_id, r.parsed_json, c.name, c.email
            FROM resumes r
            JOIN candidates c ON r.candidate_id = c.id
            ORDER BY r.uploaded_at DESC
        """)
        resume_rows = cursor.fetchall()
        
        if not resume_rows:
            st.warning("No resumes uploaded yet.")
            conn.close()
            return None
        
        results = []
        
        for resume_row in resume_rows:
            resume_id = resume_row["id"]
            candidate_id = resume_row["candidate_id"]
            candidate_name = resume_row["name"]
            candidate_email = resume_row["email"]
            
            try:
                parsed_data = json.loads(resume_row["parsed_json"] or "{}")
            except json.JSONDecodeError:
                parsed_data = {}
            
            success, ranking_id, match_score, reasons = rank_job(
                jd_text=job_description,
                resume_features=parsed_data,
                job_id=1,  # Temporary job ID for screening
                candidate_id=candidate_id,
                resume_id=resume_id,
                min_years_required=min_years_required,
                db_path=DB_PATH,
            )
            
            if success:
                resume_skills = parsed_data.get("skills", [])
                matched_skills = [s for s in must_have_skills if s in resume_skills]
                missing_skills = [s for s in must_have_skills if s not in resume_skills]
                coverage = f"{len(matched_skills)}/{len(must_have_skills)}"
                
                results.append({
                    "Candidate": candidate_name,
                    "Email": candidate_email,
                    "Match Score": round(match_score, 4),
                    "Matched Skills": ", ".join(matched_skills) if matched_skills else "None",
                    "Missing Skills": ", ".join(missing_skills) if missing_skills else "None",
                    "Coverage": coverage,
                    "Years": parsed_data.get("total_years", 0.0),
                    "Total Skills": parsed_data.get("skill_count", 0),
                })
        
        conn.close()
        
        if results:
            df = pd.DataFrame(results)
            df = df.sort_values("Match Score", ascending=False)
            return df
        else:
            st.warning("No results found.")
            return None
            
    except Exception as e:
        st.error(f"Error screening resumes: {e}")
        return None


# ============================================================================
# Main UI
# ============================================================================

# Sidebar for resume upload
with st.sidebar:
    st.header("📄 Upload JD")

    jd_files = st.file_uploader(
        "Select JD file(s) (JSON or TXT)",
        type=["json", "txt"],
        accept_multiple_files=True,
        key="jd_file_uploader",
    )

    if jd_files:
        st.info(f"📌 {len(jd_files)} JD file(s) selected")
        if st.button("Load JD Into Form", key="load_jd_button"):
            load_jd_from_uploaded_files(jd_files)

    st.markdown("---")

    st.header("📤 Upload Resumes")
    
    uploaded_files = st.file_uploader(
        "Select resume files (PDF, DOCX, TXT)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
    )
    
    if uploaded_files:
        st.info(f"📌 {len(uploaded_files)} file(s) selected")
        
        if st.button("Upload & Parse Resumes", key="upload_button"):
            with st.spinner("Uploading and parsing resumes..."):
                for uploaded_file in uploaded_files:
                    # Extract candidate info from filename if possible
                    filename_base = Path(uploaded_file.name).stem
                    candidate_name = filename_base.replace("_", " ").title()
                    
                    result = upload_and_parse_resume(
                        uploaded_file,
                        candidate_name=candidate_name,
                        candidate_email=None,
                    )
                    
                    if result:
                        st.session_state.uploaded_resumes.append(result)
                        st.success(f"✅ Uploaded: {result['candidate_name']}")
    
    st.markdown("---")
    
    # Display uploaded resumes count
    if st.session_state.uploaded_resumes:
        st.success(f"✅ {len(st.session_state.uploaded_resumes)} resume(s) in database")

st.info(
    "💡 **Scoring Formula:**\n"
    "0.55×similarity + 0.35×coverage + 0.10×experience - penalty"
)

st.markdown("---")

# Main content area
col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("📝 Job Description")
    job_description = st.text_area(
        "Enter job description:",
        height=200,
        placeholder="Describe the job requirements, responsibilities, and desired skills...",
        key="job_desc",
    )

with col2:
    st.subheader("🎯 Must-Have Skills")
    skills_input = st.text_input(
        "Enter must-have skills (comma-separated):",
        placeholder="e.g., python, sql, power bi",
        key="skills",
    )
    must_have_skills = [s.strip().lower() for s in skills_input.split(",") if s.strip()]
    
    st.metric("Skills Required", len(must_have_skills))
    
    if must_have_skills:
        st.caption("Must-have skills:")
        for skill in must_have_skills:
            st.write(f"• {skill}")

st.markdown("---")

# Experience requirement
min_years = st.number_input(
    "Minimum years of experience required:",
    min_value=0.0,
    max_value=50.0,
    step=0.5,
    value=st.session_state.min_years,
)

# Screen resumes button
col_button, col_info = st.columns([2, 3])

with col_button:
    if st.button("🔍 Screen Resumes", key="screen_button", use_container_width=True):
        if not job_description.strip():
            st.error("❌ Please enter a job description")
        elif not must_have_skills:
            st.error("❌ Please enter at least one must-have skill")
        else:
            with st.spinner("Screening resumes..."):
                results_df = screen_resumes(
                    job_description=job_description,
                    must_have_skills=must_have_skills,
                    min_years_required=min_years,
                )
                
                if results_df is not None:
                    st.session_state.ranking_results = results_df
                    st.success("✅ Screening complete!")

with col_info:
    st.info(
        "💡 **Scoring Formula:**\n"
        "0.55×similarity + 0.35×coverage + 0.10×experience - penalty"
    )

# Display results
if st.session_state.ranking_results is not None and not st.session_state.ranking_results.empty:
    st.subheader("📊 Screening Results")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    results_df = st.session_state.ranking_results
    
    with col1:
        st.metric("Total Candidates", len(results_df))
    
    with col2:
        avg_score = results_df["Match Score"].mean()
        st.metric("Average Score", f"{avg_score:.3f}")
    
    with col3:
        perfect_matches = len(results_df[results_df["Coverage"] == f"{len(must_have_skills)}/{len(must_have_skills)}"])
        st.metric("Perfect Skill Matches", perfect_matches)
    
    with col4:
        top_score = results_df["Match Score"].max()
        st.metric("Top Score", f"{top_score:.3f}")
    
    st.markdown("---")
    
    # Detailed results table
    st.subheader("Ranked Candidates")
    
    # Format dataframe for display
    display_df = results_df.copy()
    display_df["Match Score"] = display_df["Match Score"].apply(lambda x: f"{x:.4f}")
    display_df["Years"] = display_df["Years"].apply(lambda x: f"{x:.1f}")
    
    # Color coding for better visibility
    st.dataframe(
        display_df,
        use_container_width=True,
        height=400,
    )
    
    # Export option
    st.markdown("---")
    csv_data = results_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Results as CSV",
        data=csv_data,
        file_name="screening_results.csv",
        mime="text/csv",
    )
else:
    if st.session_state.ranking_results is not None:
        st.info("📌 No results to display. Upload resumes and enter job details to screen.")


# Footer
st.markdown("---")
st.caption(
    "**Automated Resume Screening Tool** | "
    "AI-powered resume matching and ranking | "
    "v1.0"
)
