"""Resume parsing helpers for skill matching and experience extraction."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List

from rapidfuzz import fuzz, process


SKILLS = [
    "python",
    "pandas",
    "sql",
    "power bi",
    "aws",
    "docker",
    "kubernetes",
    "machine learning",
    "data analysis",
    "excel",
    "tableau",
    "nlp",
    "tensorflow",
    "pytorch",
    "git",
    "linux",
    "javascript",
    "java",
    "c++",
    "spark",
]

_TOKEN_RE = re.compile(r"[a-z0-9+#.]+")
_EXP_PATTERNS = [
    re.compile(r"(?P<years>\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?|yr)\s*(?:of\s*)?(?:experience|exp)?", re.IGNORECASE),
    re.compile(r"(?:experience|exp)\s*(?:of\s*)?(?P<years>\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?|yr)", re.IGNORECASE),
]

_MONTH_NAME_TO_NUM = {
    "jan": 1,
    "january": 1,
    "feb": 2,
    "february": 2,
    "mar": 3,
    "march": 3,
    "apr": 4,
    "april": 4,
    "may": 5,
    "jun": 6,
    "june": 6,
    "jul": 7,
    "july": 7,
    "aug": 8,
    "august": 8,
    "sep": 9,
    "sept": 9,
    "september": 9,
    "oct": 10,
    "october": 10,
    "nov": 11,
    "november": 11,
    "dec": 12,
    "december": 12,
}

_DURATION_PATTERNS = [
    re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?:years?|yrs?|yr)\b", re.IGNORECASE),
    re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?:months?|mos?|mo)\b", re.IGNORECASE),
]

_DATE_RANGE_PATTERNS = [
    re.compile(
        r"(?P<start>(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)[\s./-]+\d{4}|\d{1,2}[/-]\d{4}|\d{4})\s*(?:-|to|–|—)\s*(?P<end>present|current|now|(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)[\s./-]+\d{4}|\d{1,2}[/-]\d{4}|\d{4})",
        re.IGNORECASE,
    ),
]


def _normalize_text(text: str) -> str:
    text = text or ""
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _build_ngrams(tokens: List[str], min_size: int = 1, max_size: int = 3) -> List[str]:
    phrases: List[str] = []
    token_count = len(tokens)
    for size in range(min_size, max_size + 1):
        for start in range(0, token_count - size + 1):
            phrases.append(" ".join(tokens[start : start + size]))
    return phrases


def _parse_month_token(token: str) -> tuple[int | None, int | None]:
    token = token.strip().lower().replace(".", "")

    month_year_match = re.match(r"^(?P<month>[a-z]+)[\s/-]+(?P<year>\d{4})$", token)
    if month_year_match:
        return _MONTH_NAME_TO_NUM.get(month_year_match.group("month")), int(month_year_match.group("year"))

    numeric_month_year_match = re.match(r"^(?P<month>\d{1,2})[/-](?P<year>\d{4})$", token)
    if numeric_month_year_match:
        return int(numeric_month_year_match.group("month")), int(numeric_month_year_match.group("year"))

    year_only_match = re.match(r"^(?P<year>\d{4})$", token)
    if year_only_match:
        return None, int(year_only_match.group("year"))

    return None, None


def _months_between(start_token: str, end_token: str) -> float | None:
    start_month, start_year = _parse_month_token(start_token)
    end_month, end_year = _parse_month_token(end_token)

    if start_year is None or end_year is None:
        return None

    if end_token.lower() in {"present", "current", "now"}:
        now = datetime.now()
        end_year = now.year
        end_month = now.month
    elif end_month is None:
        end_month = 12

    if start_month is None:
        start_month = 1

    month_delta = (end_year - start_year) * 12 + (end_month - start_month)
    if month_delta < 0:
        return None

    return month_delta / 12.0


def _extract_date_range_years(text: str) -> List[float]:
    values: List[float] = []
    for pattern in _DATE_RANGE_PATTERNS:
        for match in pattern.finditer(text):
            years = _months_between(match.group("start"), match.group("end"))
            if years is not None:
                values.append(years)
    return values


def fuzzy_skills(text: str, score_cutoff: int = 85) -> List[str]:
    """Return skills from the hardcoded list that fuzzily match the text."""
    normalized_text = _normalize_text(text)
    if not normalized_text:
        return []

    tokens = _TOKEN_RE.findall(normalized_text)
    candidates = _build_ngrams(tokens, min_size=1, max_size=3)
    candidates.append(normalized_text)

    matched: List[str] = []
    for skill in SKILLS:
        best_match = process.extractOne(
            skill,
            candidates,
            scorer=fuzz.token_set_ratio,
            score_cutoff=score_cutoff,
        )
        if best_match:
            matched.append(skill)

    return matched


def total_years(text: str) -> float:
    """Extract the most likely total years of experience from resume text."""
    normalized_text = _normalize_text(text)
    if not normalized_text:
        return 0.0

    found_years: List[float] = []
    for pattern in _EXP_PATTERNS:
        for match in pattern.finditer(normalized_text):
            try:
                found_years.append(float(match.group("years")))
            except (TypeError, ValueError):
                continue

    for pattern in _DURATION_PATTERNS:
        for match in pattern.finditer(normalized_text):
            try:
                value = float(match.group("value"))
                if "month" in pattern.pattern or "mo" in pattern.pattern:
                    found_years.append(value / 12.0)
                else:
                    found_years.append(value)
            except (TypeError, ValueError):
                continue

    found_years.extend(_extract_date_range_years(normalized_text))

    if not found_years:
        return 0.0

    return round(max(found_years), 2)


def parse_resume(text: str) -> Dict[str, Any]:
    """Parse a resume into a compact feature dictionary."""
    skills = fuzzy_skills(text)
    years = total_years(text)

    return {
        "skills": skills,
        "total_years": years,
        "skill_count": len(skills),
    }