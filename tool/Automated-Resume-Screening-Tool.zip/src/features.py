"""Feature scoring for job descriptions against parsed resumes."""

from __future__ import annotations

import re
from functools import lru_cache
from math import sqrt
from typing import Any, Dict, Iterable, List, Sequence

from rapidfuzz import fuzz, process


MODEL_NAME = "all-MiniLM-L6-v2"
SKILLS = [
    "python",
    "pandas",
    "sql",
    "power bi",
    "aws",
    "docker",
    "kubernetes",
    "machine learning",
    "data analysis",
    "excel",
    "tableau",
    "nlp",
    "tensorflow",
    "pytorch",
    "git",
    "linux",
    "javascript",
    "java",
    "c++",
    "spark",
]

_EXP_PATTERNS = [
    re.compile(r"(?P<years>\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?|yr)\s*(?:of\s*)?(?:experience|exp)?", re.IGNORECASE),
    re.compile(r"(?:experience|exp)\s*(?:of\s*)?(?P<years>\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?|yr)", re.IGNORECASE),
]


def _normalize_text(text: str) -> str:
    text = text or ""
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _extract_years(text: str) -> float:
    normalized_text = _normalize_text(text)
    if not normalized_text:
        return 0.0

    found_years: List[float] = []
    for pattern in _EXP_PATTERNS:
        for match in pattern.finditer(normalized_text):
            try:
                found_years.append(float(match.group("years")))
            except (TypeError, ValueError):
                continue

    return max(found_years) if found_years else 0.0


def _normalize_skill_list(skills: Any) -> List[str]:
    if not skills:
        return []
    if isinstance(skills, str):
        return [skills]
    if isinstance(skills, Sequence):
        return [str(skill).strip().lower() for skill in skills if str(skill).strip()]
    return [str(skills).strip().lower()] if str(skills).strip() else []


def _extract_jd_skills(jd_text: str, score_cutoff: int = 85) -> List[str]:
    normalized_text = _normalize_text(jd_text)
    if not normalized_text:
        return []

    collapsed_text = normalized_text.replace(" ", "")
    extracted: List[str] = []
    for skill in SKILLS:
        collapsed_skill = skill.replace(" ", "")
        if skill in normalized_text or collapsed_skill in collapsed_text:
            extracted.append(skill)
            continue

        match = process.extractOne(
            skill,
            [normalized_text],
            scorer=fuzz.partial_ratio,
            score_cutoff=score_cutoff,
        )
        if match:
            extracted.append(skill)

    return extracted


@lru_cache(maxsize=1)
def _load_model():
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer(MODEL_NAME)


def _cosine_similarity(jd_text: str, resume_skill_text: str) -> float:
    if not jd_text.strip() or not resume_skill_text.strip():
        return 0.0

    model = _load_model()
    embeddings = model.encode(
        [jd_text, resume_skill_text],
        convert_to_tensor=True,
        normalize_embeddings=True,
    )

    def _to_list(vector: Any) -> List[float]:
        if hasattr(vector, "tolist"):
            return [float(value) for value in vector.tolist()]
        return [float(value) for value in vector]

    left = _to_list(embeddings[0])
    right = _to_list(embeddings[1])

    numerator = sum(x * y for x, y in zip(left, right))
    left_norm = sqrt(sum(x * x for x in left))
    right_norm = sqrt(sum(y * y for y in right))
    denominator = left_norm * right_norm

    if denominator == 0:
        return 0.0

    return float(numerator / denominator)


def jd_resume_features(jd_text: str, resume_features: Dict[str, Any]) -> Dict[str, Any]:
    """Compute matching features between a job description and parsed resume data."""
    resume_features = resume_features or {}
    resume_skills = _normalize_skill_list(resume_features.get("skills"))
    resume_years = float(resume_features.get("total_years") or 0.0)

    jd_skills = _extract_jd_skills(jd_text)
    jd_years = _extract_years(jd_text)

    matched_skills = [skill for skill in jd_skills if skill in resume_skills]
    missing_skills = [skill for skill in jd_skills if skill not in resume_skills]
    must_have_count = len(jd_skills)
    coverage_count = len(matched_skills)

    skill_similarity = _cosine_similarity(jd_text, " ".join(resume_skills))
    experience_gap = max(0.0, jd_years - resume_years)
    coverage_gap_ratio = (len(missing_skills) / must_have_count) if must_have_count else 0.0
    experience_gap_ratio = (experience_gap / jd_years) if jd_years else (1.0 if resume_years == 0 else 0.0)
    gap_penalty = round(min(1.0, coverage_gap_ratio + experience_gap_ratio), 4)

    return {
        "jd_skills": jd_skills,
        "resume_skills": resume_skills,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "must_have_count": must_have_count,
        "must_have_coverage_count": coverage_count,
        "skill_similarity": skill_similarity,
        "jd_years": jd_years,
        "resume_years": resume_years,
        "experience_gap": experience_gap,
        "gap_penalty": gap_penalty,
    }