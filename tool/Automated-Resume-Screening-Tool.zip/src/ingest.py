"""
Resume ingestion module for text extraction and processing
Supports PDF, DOCX, and TXT file formats
"""

import json
import re
import sqlite3
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from datetime import datetime


class TextExtractor:
    """Handles text extraction from multiple file formats"""
    
    @staticmethod
    def normalize_whitespace(text: str) -> str:
        """
        Normalize whitespace in text
        - Remove extra spaces, tabs, and newlines
        - Replace multiple spaces with single space
        - Strip leading/trailing whitespace
        
        Args:
            text (str): Raw text to normalize
            
        Returns:
            str: Normalized text
        """
        # Replace multiple whitespace characters with single space
        text = re.sub(r'\s+', ' ', text)
        # Strip leading/trailing whitespace
        text = text.strip()
        return text
    
    @staticmethod
    def read_pdf(file_path: str) -> str:
        """
        Extract text from PDF file using pdfminer.six
        
        Args:
            file_path (str): Path to PDF file
            
        Returns:
            str: Extracted text
            
        Raises:
            FileNotFoundError: If file doesn't exist
            Exception: If extraction fails
        """
        if not Path(file_path).exists():
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        
        try:
            from pdfminer.high_level import extract_text as pdf_extract_text

            text = pdf_extract_text(file_path)
            return text
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                "pdfminer.six is required to extract text from PDF files"
            ) from e
        except Exception as e:
            raise Exception(f"Error extracting text from PDF {file_path}: {e}")
    
    @staticmethod
    def read_docx(file_path: str) -> str:
        """
        Extract text from DOCX file using python-docx
        
        Args:
            file_path (str): Path to DOCX file
            
        Returns:
            str: Extracted text
            
        Raises:
            FileNotFoundError: If file doesn't exist
            Exception: If extraction fails
        """
        if not Path(file_path).exists():
            raise FileNotFoundError(f"DOCX file not found: {file_path}")
        
        try:
            from docx import Document

            doc = Document(file_path)
            paragraphs = [para.text for para in doc.paragraphs]
            text = '\n'.join(paragraphs)
            return text
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                "python-docx is required to extract text from DOCX files"
            ) from e
        except Exception as e:
            raise Exception(f"Error extracting text from DOCX {file_path}: {e}")
    
    @staticmethod
    def read_txt(file_path: str, encoding: str = 'utf-8') -> str:
        """
        Read text from TXT file
        
        Args:
            file_path (str): Path to TXT file
            encoding (str): File encoding (default: utf-8)
            
        Returns:
            str: File content
            
        Raises:
            FileNotFoundError: If file doesn't exist
            Exception: If reading fails
        """
        if not Path(file_path).exists():
            raise FileNotFoundError(f"TXT file not found: {file_path}")
        
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                text = f.read()
            return text
        except UnicodeDecodeError:
            # Try with different encoding if utf-8 fails
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    text = f.read()
                return text
            except Exception as e:
                raise Exception(f"Error reading TXT file {file_path}: {e}")
        except Exception as e:
            raise Exception(f"Error reading TXT file {file_path}: {e}")
    
    @staticmethod
    def read_text(file_path: str) -> str:
        """
        Extract clean text from resume file (PDF, DOCX, or TXT)
        Automatically detects file type and extracts text
        Normalizes whitespace
        
        Args:
            file_path (str): Path to resume file
            
        Returns:
            str: Cleaned and normalized text
            
        Raises:
            ValueError: If file type is not supported
            FileNotFoundError: If file doesn't exist
            Exception: If extraction fails
        """
        file_path = str(file_path)
        file_ext = Path(file_path).suffix.lower()
        
        # Extract text based on file type
        if file_ext == '.pdf':
            text = TextExtractor.read_pdf(file_path)
        elif file_ext == '.docx':
            text = TextExtractor.read_docx(file_path)
        elif file_ext == '.txt':
            text = TextExtractor.read_txt(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_ext}. Supported: .pdf, .docx, .txt")
        
        # Normalize whitespace
        normalized_text = TextExtractor.normalize_whitespace(text)
        
        return normalized_text


class ResumeStore:
    """Handles storing resume data to SQLite database"""
    
    def __init__(self, db_path: str = None):
        """
        Initialize resume store
        
        Args:
            db_path (str): Path to SQLite database. Defaults to db/resumes.db
        """
        if db_path is None:
            db_dir = Path(__file__).parent.parent / "db"
            db_path = str(db_dir / "resumes.db")
        
        self.db_path = db_path
    
    def get_connection(self) -> sqlite3.Connection:
        """
        Get database connection
        
        Returns:
            sqlite3.Connection: Database connection
            
        Raises:
            sqlite3.Error: If connection fails
        """
        if not Path(self.db_path).exists():
            raise FileNotFoundError(f"Database not found: {self.db_path}")
        
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            raise sqlite3.Error(f"Database connection error: {e}")
    
    def save_resume(
        self,
        candidate_id: int,
        file_path: str,
        raw_text: str,
        parsed_data: Dict[str, Any] = None
    ) -> Tuple[bool, Optional[int], str]:
        """
        Save resume to database with raw text and parsed JSON
        
        Args:
            candidate_id (int): ID of candidate in candidates table
            file_path (str): Path to resume file
            raw_text (str): Extracted raw text from resume
            parsed_data (dict): Optional parsed resume data (skills, experience, etc.)
                               Will be stored as JSON
            
        Returns:
            tuple: (success: bool, resume_id: int or None, message: str)
        """
        if parsed_data is None:
            parsed_data = {}
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get file info
            file_path_obj = Path(file_path)
            file_type = file_path_obj.suffix.lower()
            file_size = file_path_obj.stat().st_size if file_path_obj.exists() else 0
            
            # Convert parsed_data to JSON string
            parsed_json = json.dumps(parsed_data, ensure_ascii=False)
            
            # Insert into resumes table
            cursor.execute("""
                INSERT INTO resumes 
                (candidate_id, file_path, file_type, file_size, extracted_text, parsed_json)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (candidate_id, file_path, file_type, file_size, raw_text, parsed_json))
            
            resume_id = cursor.lastrowid
            
            conn.commit()
            conn.close()
            
            return True, resume_id, f"Resume saved successfully (ID: {resume_id})"
            
        except sqlite3.IntegrityError as e:
            return False, None, f"Database integrity error: {e}"
        except sqlite3.Error as e:
            return False, None, f"Database error: {e}"
        except Exception as e:
            return False, None, f"Error saving resume: {e}"


def ingest_resume(
    file_path: str,
    candidate_id: int,
    db_path: str = None,
    parsed_data: Dict[str, Any] = None
) -> Tuple[bool, Optional[int], str]:
    """
    High-level function to ingest a resume file
    Extracts text and saves to database
    
    Args:
        file_path (str): Path to resume file
        candidate_id (int): ID of candidate
        db_path (str): Optional path to database
        parsed_data (dict): Optional parsed resume data
        
    Returns:
        tuple: (success: bool, resume_id: int or None, message: str)
    """
    try:
        # Extract text
        text = TextExtractor.read_text(file_path)
        
        # Save to database
        store = ResumeStore(db_path=db_path)
        success, resume_id, message = store.save_resume(
            candidate_id=candidate_id,
            file_path=file_path,
            raw_text=text,
            parsed_data=parsed_data
        )
        
        return success, resume_id, message
        
    except Exception as e:
        return False, None, f"Error ingesting resume: {e}"


if __name__ == "__main__":
    # Example usage
    print("Resume Ingestion Module")
    print("=" * 50)
    print("Use this module to extract text from resumes and save to database")
    print("\nExample:")
    print("  from src.ingest import ingest_resume")
    print("  success, resume_id, message = ingest_resume(")
    print("      file_path='path/to/resume.pdf',")
    print("      candidate_id=1")
    print("  )")
    print("  print(message)")
