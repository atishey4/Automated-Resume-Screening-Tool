"""Ranking and scoring for job-resume matches."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from features import jd_resume_features


def rank_job(
    jd_text: str,
    resume_features: Dict[str, Any],
    job_id: int,
    candidate_id: int,
    resume_id: int,
    min_years_required: float = 0.0,
    db_path: Optional[str] = None,
) -> Tuple[bool, Optional[int], float, Dict[str, Any]]:
    """
    Rank and score a job-resume match using composite formula.
    
    Formula: score = 0.55×sim + 0.35×(must_hits/must_total) + 0.10×min(1, years/min_req) − gap_penalty
    
    Args:
        jd_text (str): Job description text
        resume_features (dict): Parsed resume features from extract.parse_resume()
        job_id (int): Job ID in database
        candidate_id (int): Candidate ID in database
        resume_id (int): Resume ID in database
        min_years_required (float): Minimum years of experience required for the job
        db_path (str): Optional path to database
        
    Returns:
        tuple: (success, ranking_id, match_score, result_dict)
    """
    
    if db_path is None:
        db_dir = Path(__file__).parent.parent / "db"
        db_path = str(db_dir / "resumes.db")
    
    try:
        # Get feature scores
        features = jd_resume_features(jd_text, resume_features)
        
        # Extract components
        skill_similarity = features.get("skill_similarity", 0.0)
        must_total = max(1, features.get("must_have_count", 1))
        must_hits = features.get("must_have_coverage_count", 0)
        resume_years = features.get("resume_years", 0.0)
        gap_penalty = features.get("gap_penalty", 0.0)
        
        # Calculate experience component
        if min_years_required > 0:
            experience_component = min(1.0, resume_years / min_years_required)
        else:
            experience_component = 1.0 if resume_years >= 0 else 0.0
        
        # Apply formula: 0.55×sim + 0.35×(must_hits/must_total) + 0.10×exp − gap_penalty
        match_score = (
            0.55 * skill_similarity
            + 0.35 * (must_hits / must_total)
            + 0.10 * experience_component
            - gap_penalty
        )
        match_score = max(0.0, min(1.0, match_score))
        
        # Build explanation/reasons
        reasons = {
            "formula": "0.55×similarity + 0.35×(coverage) + 0.10×(years) - penalty",
            "skill_similarity": round(skill_similarity, 4),
            "skill_similarity_weight": 0.55,
            "skill_similarity_component": round(0.55 * skill_similarity, 4),
            "coverage_ratio": round(must_hits / must_total, 4),
            "coverage_ratio_weight": 0.35,
            "coverage_component": round(0.35 * (must_hits / must_total), 4),
            "experience_ratio": round(experience_component, 4),
            "experience_ratio_weight": 0.10,
            "experience_component": round(0.10 * experience_component, 4),
            "gap_penalty": round(gap_penalty, 4),
            "matched_skills": features.get("matched_skills", []),
            "missing_skills": features.get("missing_skills", []),
            "resume_years": features.get("resume_years", 0.0),
            "jd_years": features.get("jd_years", 0.0),
            "experience_gap": features.get("experience_gap", 0.0),
        }
        
        # Save to database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        skills_match_json = json.dumps({
            "matched": features.get("matched_skills", []),
            "missing": features.get("missing_skills", []),
            "coverage": f"{must_hits}/{must_total}",
        })
        
        experience_match_json = json.dumps({
            "resume_years": features.get("resume_years", 0.0),
            "jd_years": features.get("jd_years", 0.0),
            "gap": features.get("experience_gap", 0.0),
        })
        
        cursor.execute("""
            INSERT INTO rankings 
            (job_id, resume_id, candidate_id, match_score, skills_match, experience_match)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (job_id, resume_id, candidate_id, match_score, skills_match_json, experience_match_json))
        
        ranking_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return True, ranking_id, match_score, reasons
        
    except sqlite3.Error as e:
        return False, None, 0.0, {"error": f"Database error: {e}"}
    except Exception as e:
        return False, None, 0.0, {"error": f"Ranking error: {e}"}


def bulk_rank_resumes(
    jd_text: str,
    job_id: int,
    resume_data_list: list,
    min_years_required: float = 0.0,
    db_path: Optional[str] = None,
) -> list:
    """
    Rank multiple resumes against a single job.
    
    Args:
        jd_text (str): Job description text
        job_id (int): Job ID
        resume_data_list (list): List of (candidate_id, resume_id, resume_features) tuples
        min_years_required (float): Minimum years required
        db_path (str): Optional database path
        
    Returns:
        list: List of (resume_id, match_score) tuples sorted by score descending
    """
    results = []
    for candidate_id, resume_id, resume_features in resume_data_list:
        success, ranking_id, match_score, _ = rank_job(
            jd_text,
            resume_features,
            job_id,
            candidate_id,
            resume_id,
            min_years_required,
            db_path,
        )
        if success:
            results.append((resume_id, match_score))
    
    results.sort(key=lambda x: x[1], reverse=True)
    return results
