"""
Test script for resume ingest module
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ingest import TextExtractor, ResumeStore, ingest_resume


def test_text_extractor():
    """Test TextExtractor functions"""
    print("Testing TextExtractor...")
    print("-" * 50)
    
    # Test normalize_whitespace
    test_text = "  Hello   world  \n\n  This  is   a   test  "
    normalized = TextExtractor.normalize_whitespace(test_text)
    print(f"Original: {repr(test_text)}")
    print(f"Normalized: {repr(normalized)}")
    assert normalized == "Hello world This is a test", "Whitespace normalization failed"
    print("✓ normalize_whitespace() works\n")
    
    # Create sample TXT file for testing
    sample_txt = Path(__file__).parent / "sample_resume.txt"
    sample_txt.write_text("""
    John Doe
    Email: john@example.com
    Phone: +1-555-0100
    
    SKILLS:
    Python, JavaScript, SQL, Django, FastAPI
    
    EXPERIENCE:
    Senior Software Engineer at TechCorp (2020-2024)
    - Developed REST APIs using FastAPI
    - Managed database migrations
    
    Junior Developer at StartupXYZ (2018-2020)
    - Built web applications
    - Fixed bugs and improved performance
    """)
    
    # Test read_txt
    try:
        text = TextExtractor.read_text(str(sample_txt))
        print(f"Extracted text length: {len(text)} characters")
        print(f"First 100 chars: {text[:100]}\n")
        assert len(text) > 0, "Text extraction failed"
        print("✓ read_txt() works\n")
    finally:
        sample_txt.unlink()  # Clean up
    
    return True


def test_resume_store():
    """Test ResumeStore functions"""
    print("Testing ResumeStore...")
    print("-" * 50)
    
    store = ResumeStore()
    
    # Test connection
    try:
        conn = store.get_connection()
        cursor = conn.cursor()
        
        # Insert test candidate
        cursor.execute("""
            INSERT INTO candidates (name, email, phone)
            VALUES (?, ?, ?)
        """, ("John Doe", "john@example.com", "+1-555-0100"))
        conn.commit()
        candidate_id = cursor.lastrowid
        print(f"✓ Created test candidate (ID: {candidate_id})\n")
        
        conn.close()
    except Exception as e:
        print(f"✗ Connection test failed: {e}")
        return False
    
    # Test save_resume
    sample_resume_path = Path(__file__).parent / "test_resume.txt"
    sample_resume_path.write_text("""
    JOHN DOE
    Senior Python Developer
    
    TECHNICAL SKILLS:
    Python, Django, FastAPI, PostgreSQL, MongoDB
    Machine Learning, Data Analysis
    
    PROFESSIONAL EXPERIENCE:
    TechCorp - Senior Software Engineer (2020-2024)
    StartupXYZ - Junior Developer (2018-2020)
    """)
    
    try:
        sample_text = TextExtractor.read_text(str(sample_resume_path))
        
        parsed_data = {
            "name": "John Doe",
            "title": "Senior Python Developer",
            "skills": ["Python", "Django", "FastAPI", "PostgreSQL"],
            "years_experience": 6
        }
        
        success, resume_id, message = store.save_resume(
            candidate_id=candidate_id,
            file_path=str(sample_resume_path),
            raw_text=sample_text,
            parsed_data=parsed_data
        )
        
        print(f"Save result: {message}")
        if success:
            print(f"✓ Resume saved (ID: {resume_id})\n")
        else:
            print(f"✗ Failed to save resume\n")
            return False
        
        return True
    finally:
        sample_resume_path.unlink()  # Clean up


if __name__ == "__main__":
    print("Resume Ingest Module Tests")
    print("=" * 50)
    print()
    
    try:
        if test_text_extractor():
            print()
        
        if test_resume_store():
            print()
            print("=" * 50)
            print("✓ All tests passed!")
        else:
            print("✗ Some tests failed")
            sys.exit(1)
    except Exception as e:
        print(f"✗ Test error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
